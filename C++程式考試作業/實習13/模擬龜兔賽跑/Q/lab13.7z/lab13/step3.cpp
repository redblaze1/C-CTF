#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include "race.h"

using namespace std;
void printCurrentPositions( const int * const snapperPtr, 
   const int * const bunnyPtr );


const int RACE_END = 70;

void moveTortoise( int *const );
void moveHare( int * const );

int main(){

    int tortoise=1;
    int hare = 1;
    
    srand( time( 0 ) );
    
    while ( tortoise != RACE_END && hare != RACE_END ) 
   {
      Sleep( 100 );
      Clr();
	      
      moveTortoise( &tortoise );
      moveHare(&hare);
      printCurrentPositions( &tortoise, &hare );
      
   } // end loop
   
    

   // system("PAUSE");
}
void moveTortoise( int * const turtlePtr )
{
 
 
 
 
}  // end function moveTortoise

void moveHare( int * const rabbitPtr )
{
  
} // end function moveHare

void printCurrentPositions( const int * const snapperPtr, 
   const int * const bunnyPtr )
{

   
} // end function printCurrentPositions
