#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include "race.h"

using namespace std;
void printCurrentPositions( const int * const snapperPtr, 
   const int * const bunnyPtr );


const int RACE_END = 70;

void moveTortoise( int *const );


int main(){

    int tortoise=1;
    int hare = 1;
    
    srand( time( 0 ) );
    
    while ( tortoise != RACE_END && hare != RACE_END ) 
   {
      Sleep( 500 );
      Clr();    
      moveTortoise( &tortoise );
      printCurrentPositions( &tortoise, &hare );
      //timer++;
   } // end loop
   
    

   // system("PAUSE");
}
void moveTortoise( int * const turtlePtr )
{
  
}

void printCurrentPositions( const int * const snapperPtr, 
   const int * const bunnyPtr )
{


   
}
