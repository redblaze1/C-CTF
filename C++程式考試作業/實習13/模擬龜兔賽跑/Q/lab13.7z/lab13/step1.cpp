#include <iostream>
#include <iomanip>
#include "race.h"
using namespace std;
void printCurrentPositions( const int * const snapperPtr, 
   const int * const bunnyPtr );
   //snapper turtle �Q�t
   //bunny �ߤl

const int RACE_END = 70;
    
int main(){

    
    
    int tortoise=10;  //tortoise ���t
    int hare = 20;  //hare ����
    printCurrentPositions(&tortoise, &hare);

    //system("PAUSE");
}

void printCurrentPositions( const int * const snapperPtr, 
   const int * const bunnyPtr )
{

   
   
} // end function printCurrentPositions
